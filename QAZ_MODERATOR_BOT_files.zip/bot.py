import os
import re
import time
import asyncio
import sqlite3
from collections import defaultdict, deque
from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.enums import ChatType
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton,
    Update
)
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
WEBHOOK_URL = os.getenv("WEBHOOK_URL", "").strip().rstrip("/")
DEVELOPER_ID = int(os.getenv("DEVELOPER_ID", "8453902853"))
PORT = int(os.getenv("PORT", "10000"))
WEBHOOK_PATH = "/telegram-webhook"
DB_PATH = os.getenv("DB_PATH", "qaz_moderator.sqlite3")

if not BOT_TOKEN:
    raise RuntimeError("Missing BOT_TOKEN environment variable")
if not WEBHOOK_URL:
    raise RuntimeError("Missing WEBHOOK_URL environment variable. Set it to your Render service URL.")

bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()
recent_messages = defaultdict(lambda: deque(maxlen=12))
db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.row_factory = sqlite3.Row

def init_db():
    db.executescript("""
    CREATE TABLE IF NOT EXISTS chat_settings (
        chat_id INTEGER PRIMARY KEY,
        anti_spam INTEGER NOT NULL DEFAULT 1,
        block_links INTEGER NOT NULL DEFAULT 0,
        bad_words TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS warnings (
        chat_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        count INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY(chat_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        chat_id INTEGER,
        actor_id INTEGER,
        target_id INTEGER,
        action TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS known_chats (
        chat_id INTEGER PRIMARY KEY,
        title TEXT
    );
    """)
    db.commit()

def log_action(chat_id, actor_id, target_id, action):
    db.execute("INSERT INTO logs(chat_id, actor_id, target_id, action) VALUES (?, ?, ?, ?)",
               (chat_id, actor_id, target_id, action))
    db.commit()

def get_settings(chat_id):
    row = db.execute("SELECT * FROM chat_settings WHERE chat_id=?", (chat_id,)).fetchone()
    if row is None:
        db.execute("INSERT OR IGNORE INTO chat_settings(chat_id) VALUES (?)", (chat_id,))
        db.commit()
        row = db.execute("SELECT * FROM chat_settings WHERE chat_id=?", (chat_id,)).fetchone()
    return row

def is_developer(user_id):
    return user_id == DEVELOPER_ID

async def is_chat_admin(chat_id, user_id):
    try:
        member = await bot.get_chat_member(chat_id, user_id)
        return member.status in ("administrator", "creator")
    except Exception:
        return False

async def require_group_admin(message: Message):
    if not message.from_user or not message.chat:
        return False
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        await message.reply("Эта команда работает внутри группы.")
        return False
    if not await is_chat_admin(message.chat.id, message.from_user.id) and not is_developer(message.from_user.id):
        await message.reply("⛔ Команда доступна только администраторам чата.")
        return False
    return True

def target_from_reply(message: Message):
    if message.reply_to_message and message.reply_to_message.from_user:
        return message.reply_to_message.from_user
    return None

def main_keyboard(user_id):
    rows = [
        [InlineKeyboardButton(text="🛡️ Панель модерации", callback_data="admin_panel")],
    ]
    if is_developer(user_id):
        rows.append([InlineKeyboardButton(text="👑 Панель разработчика", callback_data="dev_panel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

@dp.message(CommandStart())
async def start(message: Message):
    text = (
        "👑 <b>QAZ MODERATOR BOT</b>\n\n"
        "Бот для модерации Telegram-групп.\n"
        "Добавь меня в группу и выдай права администратора: удаление сообщений, "
        "ограничение участников и блокировка пользователей.\n\n"
        "Команды модерации выполняются ответом на сообщение пользователя."
    )
    await message.answer(text, reply_markup=main_keyboard(message.from_user.id))

@dp.message(Command("help"))
async def help_command(message: Message):
    await message.answer(
        "<b>Команды модерации</b>\n"
        "Ответь на сообщение пользователя и используй:\n"
        "/ban — заблокировать\n/mute 10 — мут на 10 минут\n"
        "/unmute — снять мут\n/kick — исключить\n/warn — предупреждение\n"
        "/purge — удалить сообщения выше выбранного сообщения (ограниченно)\n\n"
        "Настройки: открой /start в личке и выбери панель."
    )

@dp.message(Command("ban"))
async def ban_user(message: Message):
    if not await require_group_admin(message): return
    target = target_from_reply(message)
    if not target:
        await message.reply("Ответь командой /ban на сообщение пользователя.")
        return
    try:
        await bot.ban_chat_member(message.chat.id, target.id)
        log_action(message.chat.id, message.from_user.id, target.id, "ban")
        await message.reply(f"🔨 Пользователь <code>{target.id}</code> заблокирован.")
    except Exception as e:
        await message.reply("Не удалось заблокировать пользователя. Проверь права бота.")

@dp.message(Command("unban"))
async def unban_user(message: Message):
    if not await require_group_admin(message): return
    args = (message.text or "").split()
    if len(args) < 2 or not args[1].lstrip("-").isdigit():
        await message.reply("Использование: /unban USER_ID")
        return
    target_id = int(args[1])
    try:
        await bot.unban_chat_member(message.chat.id, target_id, only_if_banned=True)
        log_action(message.chat.id, message.from_user.id, target_id, "unban")
        await message.reply(f"✅ Пользователь <code>{target_id}</code> разблокирован.")
    except Exception:
        await message.reply("Не удалось выполнить разбан. Проверь ID и права бота.")

@dp.message(Command("mute"))
async def mute_user(message: Message):
    if not await require_group_admin(message): return
    target = target_from_reply(message)
    if not target:
        await message.reply("Ответь командой /mute на сообщение. Пример: /mute 10")
        return
    args = (message.text or "").split()
    minutes = 10
    if len(args) > 1 and args[1].isdigit():
        minutes = max(1, min(int(args[1]), 10080))
    from datetime import datetime, timedelta, timezone
    until = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    try:
        await bot.restrict_chat_member(
            message.chat.id, target.id,
            permissions={"can_send_messages": False, "can_send_audios": False,
                         "can_send_documents": False, "can_send_photos": False,
                         "can_send_videos": False, "can_send_video_notes": False,
                         "can_send_voice_notes": False, "can_send_polls": False,
                         "can_send_other_messages": False, "can_add_web_page_previews": False},
            until_date=until
        )
        log_action(message.chat.id, message.from_user.id, target.id, f"mute:{minutes}")
        await message.reply(f"🔇 Пользователь <code>{target.id}</code> получил мут на {minutes} мин.")
    except Exception:
        await message.reply("Не удалось выдать мут. Проверь права бота.")

@dp.message(Command("unmute"))
async def unmute_user(message: Message):
    if not await require_group_admin(message): return
    target = target_from_reply(message)
    if not target:
        await message.reply("Ответь командой /unmute на сообщение пользователя.")
        return
    try:
        await bot.restrict_chat_member(
            message.chat.id, target.id,
            permissions={"can_send_messages": True, "can_send_audios": True,
                         "can_send_documents": True, "can_send_photos": True,
                         "can_send_videos": True, "can_send_video_notes": True,
                         "can_send_voice_notes": True, "can_send_polls": True,
                         "can_send_other_messages": True, "can_add_web_page_previews": True}
        )
        log_action(message.chat.id, message.from_user.id, target.id, "unmute")
        await message.reply(f"🔊 Мут снят с <code>{target.id}</code>.")
    except Exception:
        await message.reply("Не удалось снять мут. Проверь права бота.")

@dp.message(Command("kick"))
async def kick_user(message: Message):
    if not await require_group_admin(message): return
    target = target_from_reply(message)
    if not target:
        await message.reply("Ответь командой /kick на сообщение пользователя.")
        return
    try:
        await bot.ban_chat_member(message.chat.id, target.id)
        await bot.unban_chat_member(message.chat.id, target.id, only_if_banned=True)
        log_action(message.chat.id, message.from_user.id, target.id, "kick")
        await message.reply(f"👢 Пользователь <code>{target.id}</code> исключён.")
    except Exception:
        await message.reply("Не удалось исключить пользователя. Проверь права бота.")

@dp.message(Command("warn"))
async def warn_user(message: Message):
    if not await require_group_admin(message): return
    target = target_from_reply(message)
    if not target:
        await message.reply("Ответь командой /warn на сообщение пользователя.")
        return
    db.execute("INSERT INTO warnings(chat_id,user_id,count) VALUES(?,?,1) "
               "ON CONFLICT(chat_id,user_id) DO UPDATE SET count=count+1",
               (message.chat.id, target.id))
    db.commit()
    count = db.execute("SELECT count FROM warnings WHERE chat_id=? AND user_id=?",
                       (message.chat.id, target.id)).fetchone()["count"]
    log_action(message.chat.id, message.from_user.id, target.id, "warn")
    if count >= 3:
        try:
            await bot.restrict_chat_member(message.chat.id, target.id,
                permissions={"can_send_messages": False}, until_date=int(time.time()) + 600)
            await message.reply(f"⚠️ Предупреждение {count}/3. Пользователь получил мут на 10 минут.")
        except Exception:
            await message.reply(f"⚠️ Предупреждение {count}. Не удалось автоматически выдать мут.")
    else:
        await message.reply(f"⚠️ Предупреждение пользователю <code>{target.id}</code>: {count}/3.")

@dp.message(Command("purge"))
async def purge(message: Message):
    if not await require_group_admin(message): return
    if not message.reply_to_message:
        await message.reply("Ответь /purge на сообщение: удалятся оно и команда.")
        return
    try:
        start_id = message.reply_to_message.message_id
        end_id = message.message_id
        # Telegram API does not offer bulk delete; cap the range to 100 messages.
        ids = list(range(max(start_id, end_id - 99), end_id + 1))
        await bot.delete_messages(message.chat.id, ids)
    except Exception:
        try: await message.reply("Не удалось удалить сообщения. Старые сообщения удалить нельзя.")
        except Exception: pass

@dp.callback_query(F.data == "admin_panel")
async def admin_panel(call: CallbackQuery):
    if not call.from_user:
        await call.answer(); return
    chats = db.execute("SELECT chat_id,title FROM known_chats ORDER BY title").fetchall()
    accessible = []
    for row in chats:
        if await is_chat_admin(row["chat_id"], call.from_user.id) or is_developer(call.from_user.id):
            accessible.append(row)
    text = "🛡️ <b>Панель модерации</b>\n\n"
    if accessible:
        text += "Бот запомнил следующие чаты:\n" + "\n".join(
            f"• {r['title'] or r['chat_id']} (<code>{r['chat_id']}</code>)" for r in accessible
        )
    else:
        text += "Пока нет доступных чатов. Добавь бота в группу, выдай права администратора и отправь там любое сообщение."
    text += "\n\nКоманды в группе: /ban, /unban ID, /mute 10, /unmute, /kick, /warn."
    await call.message.edit_text(text, reply_markup=main_keyboard(call.from_user.id))
    await call.answer()

@dp.callback_query(F.data == "dev_panel")
async def dev_panel(call: CallbackQuery):
    if not call.from_user or not is_developer(call.from_user.id):
        await call.answer("Доступ запрещён.", show_alert=True); return
    chats = db.execute("SELECT COUNT(*) n FROM known_chats").fetchone()["n"]
    logs = db.execute("SELECT COUNT(*) n FROM logs").fetchone()["n"]
    text = (
        "👑 <b>Панель разработчика</b>\n\n"
        f"Зарегистрировано чатов: <b>{chats}</b>\n"
        f"Записей в журнале: <b>{logs}</b>\n\n"
        "Команда /broadcast ТЕКСТ — рассылка по чатам, где бот видел сообщения.\n"
        "Используй рассылку только для сообщений, которые уместны для этих чатов."
    )
    await call.message.edit_text(text, reply_markup=main_keyboard(call.from_user.id))
    await call.answer()

@dp.message(Command("broadcast"))
async def broadcast(message: Message):
    if not message.from_user or not is_developer(message.from_user.id):
        await message.reply("⛔ Доступ запрещён.")
        return
    text = (message.text or "").partition(" ")[2].strip()
    if not text:
        await message.reply("Использование: /broadcast Текст сообщения")
        return
    chats = db.execute("SELECT chat_id FROM known_chats").fetchall()
    ok = 0
    for row in chats:
        try:
            await bot.send_message(row["chat_id"], text)
            ok += 1
            await asyncio.sleep(0.05)
        except Exception:
            pass
    await message.reply(f"📢 Рассылка завершена. Отправлено в чатов: {ok} из {len(chats)}.")

@dp.message(lambda message: not ((message.text or "").startswith("/")))
async def group_guard(message: Message):
    if message.chat.type not in (ChatType.GROUP, ChatType.SUPERGROUP):
        return
    if message.chat.id:
        db.execute("INSERT INTO known_chats(chat_id,title) VALUES(?,?) "
                   "ON CONFLICT(chat_id) DO UPDATE SET title=excluded.title",
                   (message.chat.id, message.chat.title or str(message.chat.id)))
        db.commit()
        get_settings(message.chat.id)
    if not message.from_user or message.from_user.is_bot:
        return
    # Only moderate ordinary members; do not automatically punish group admins.
    if await is_chat_admin(message.chat.id, message.from_user.id) or is_developer(message.from_user.id):
        return
    settings = get_settings(message.chat.id)
    text = message.text or message.caption or ""
    if settings["block_links"] and re.search(r"(https?://|www\.|t\.me/|telegram\.me/)", text, re.I):
        try:
            await message.delete()
            log_action(message.chat.id, 0, message.from_user.id, "link_deleted")
        except Exception:
            pass
        return
    bad_words = [w.strip().lower() for w in settings["bad_words"].split(",") if w.strip()]
    if any(word in text.lower() for word in bad_words):
        try:
            await message.delete()
            log_action(message.chat.id, 0, message.from_user.id, "bad_word_deleted")
        except Exception:
            pass
        return
    if settings["anti_spam"]:
        now = time.time()
        q = recent_messages[(message.chat.id, message.from_user.id)]
        q.append((now, text[:200]))
        while q and now - q[0][0] > 6:
            q.popleft()
        repeated = len(q) >= 5 and len({item[1] for item in list(q)[-5:]}) <= 2
        if len(q) >= 7 or repeated:
            try:
                await bot.restrict_chat_member(
                    message.chat.id, message.from_user.id,
                    permissions={"can_send_messages": False},
                    until_date=int(now) + 60
                )
                await message.reply("🚫 Антифлуд: мут на 1 минуту.")
                log_action(message.chat.id, 0, message.from_user.id, "anti_flood_mute")
                q.clear()
            except Exception:
                pass

@dp.message(Command("modsettings"))
async def modsettings(message: Message):
    if not await require_group_admin(message): return
    args = (message.text or "").split(maxsplit=2)
    if len(args) < 2:
        s = get_settings(message.chat.id)
        await message.reply(
            "Настройки:\n"
            f"anti_spam: {bool(s['anti_spam'])}\n"
            f"block_links: {bool(s['block_links'])}\n"
            f"bad_words: {s['bad_words'] or '(нет)'}\n\n"
            "Команды:\n/modsettings spam on|off\n"
            "/modsettings links on|off\n"
            "/modsettings words слово1,слово2"
        )
        return
    key = args[1].lower()
    value = args[2].strip() if len(args) > 2 else ""
    if key == "spam" and value in ("on", "off"):
        db.execute("UPDATE chat_settings SET anti_spam=? WHERE chat_id=?", (1 if value=="on" else 0, message.chat.id))
    elif key == "links" and value in ("on", "off"):
        db.execute("UPDATE chat_settings SET block_links=? WHERE chat_id=?", (1 if value=="on" else 0, message.chat.id))
    elif key == "words":
        db.execute("UPDATE chat_settings SET bad_words=? WHERE chat_id=?", (value[:1000], message.chat.id))
    else:
        await message.reply("Неверная команда. Используй /modsettings")
        return
    db.commit()
    await message.reply("✅ Настройки сохранены.")

async def on_startup(bot: Bot):
    init_db()
    await bot.set_webhook(f"{WEBHOOK_URL}{WEBHOOK_PATH}", drop_pending_updates=True)

async def on_shutdown(bot: Bot):
    await bot.delete_webhook()
    db.close()

dp.startup.register(on_startup)
dp.shutdown.register(on_shutdown)

async def health(request):
    return web.Response(text="QAZ MODERATOR BOT is running")

def main():
    app = web.Application()
    app.router.add_get("/", health)
    app.router.add_post(WEBHOOK_PATH, SimpleRequestHandler(dispatcher=dp, bot=bot))
    setup_application(app, dp, bot=bot)
    web.run_app(app, host="0.0.0.0", port=PORT)

if __name__ == "__main__":
    main()
