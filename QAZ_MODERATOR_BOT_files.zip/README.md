# QAZ MODERATOR BOT

Telegram moderation bot using Python, aiogram 3, aiohttp webhooks and SQLite.

## Render environment variables
- `BOT_TOKEN`: token from BotFather (keep secret)
- `WEBHOOK_URL`: public HTTPS URL of your Render web service, e.g. `https://your-service.onrender.com`
- `DEVELOPER_ID`: `8453902853`

## Deploy
Create a Render Web Service from this GitHub repository. Build command:
`pip install -r requirements.txt`
Start command:
`python bot.py`

Important: Render's free web services may sleep and are not guaranteed to run 24/7. SQLite files on ephemeral free instances may be lost on redeploy/restart. Use persistent storage or an external database for durable production use.

## First steps
1. Set the environment variables in Render.
2. Deploy the service.
3. Open the service URL; it should say `QAZ MODERATOR BOT is running`.
4. Add the bot to a group and grant admin rights needed for deleting messages, restricting users and banning users.
5. Send `/start` to the bot privately.

## Commands
- Reply `/ban` to a user's message
- `/unban USER_ID`
- Reply `/mute 10` to mute for 10 minutes
- Reply `/unmute`
- Reply `/kick`
- Reply `/warn`
- `/modsettings` to view settings
- `/modsettings spam on|off`
- `/modsettings links on|off`
- `/modsettings words word1,word2`
- Developer only: `/broadcast message`

This is a starter implementation. Test in a private test group before using it in a real community.
